# HBD PROCAST ProBill — Android App

**GST Billing System for HBD PROCAST | Aluminium Die Casting Parts**

## Quick Build (3 Steps)

### Prerequisites
- Install [Android Studio](https://developer.android.com/studio) (includes Android SDK)
- Java 11+ (bundled with Android Studio)

### Build Steps

**Option 1 — Auto Script (Recommended)**
```bash
# macOS / Linux
./BUILD.sh

# Windows
BUILD.bat
```

**Option 2 — Android Studio**
1. Open Android Studio → `Open Project` → select this folder
2. Wait for Gradle sync to complete
3. Menu: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
4. APK saved to: `app/build/outputs/apk/debug/`

**Option 3 — Command Line**
```bash
# Set Android SDK path (auto-detected by BUILD.sh)
export ANDROID_HOME=~/Library/Android/sdk   # Mac
export ANDROID_HOME=~/Android/Sdk           # Linux
set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk # Windows

echo "sdk.dir=$ANDROID_HOME" > local.properties
chmod +x gradlew
./gradlew assembleDebug
```

## APK Output Location
```
app/build/outputs/apk/
  debug/   app-debug.apk     ← Install directly on any Android device
  release/ app-release-unsigned.apk
```

## Install on Android Device
```bash
# Via ADB (USB cable)
adb install app/build/outputs/apk/debug/app-debug.apk

# Or copy APK to phone → tap to install
# (Enable: Settings → Security → Unknown Sources)
```

## Auto-Build with GitHub Actions
1. Push this project to a GitHub repository
2. Go to `Actions` tab → `Build HBD ProBill APK`
3. Click `Run workflow`
4. Download APK from `Artifacts` when build completes

## App Features
- ✅ GST Invoice Generation (CGST/SGST/IGST)
- ✅ Invoice History with search
- ✅ Customer management
- ✅ Payment tracking
- ✅ PDF save to `/Downloads/HBD Invoices/`
- ✅ Share via WhatsApp / Email
- ✅ Print to any printer
- ✅ Offline support (no internet needed)
- ✅ Local storage (data persists across sessions)
- ✅ HBD PROCAST branding throughout

## Technical Stack
- React 19 + esbuild (bundled)
- Android WebView (API 23+)
- Native Android bridge (PDF/Share/Print)
- FileProvider for secure file sharing

## App Info
- Package: `com.hbdprocast.billing`
- Min Android: 6.0 (API 23)
- Target Android: 14 (API 34)
- Version: 1.0.0
