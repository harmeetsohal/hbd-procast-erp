package com.hbdprocast.billing;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;
    private static final int PERMISSION_REQUEST = 100;
    private static final int FILE_CHOOSER_REQUEST = 101;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full screen immersive
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#0b2160"));
            getWindow().setNavigationBarColor(Color.parseColor("#0b2160"));
        }

        // Request storage permissions
        requestStoragePermissions();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0b2160"));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(false);
        }

        // Add JavaScript bridge
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Inject Android helpers into JS
                view.evaluateJavascript(
                    "window.isAndroidApp = true;" +
                    "window.androidVersion = " + Build.VERSION.SDK_INT + ";" +
                    "window._hbdGoBack = function(){ AndroidBridge.goBack(); };" +
                    "console.log('HBD PROCAST Android Bridge Ready');",
                    null
                );
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            }
        });

        // Enable WebView debugging in debug builds
        WebView.setWebContentsDebuggingEnabled(false);

        // Load the app from assets
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        }, PERMISSION_REQUEST);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    results = new Uri[]{data.getData()};
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // JavaScript bridge for Android native features
    public class AndroidBridge {

        @JavascriptInterface
        public void goBack() {
            runOnUiThread(() -> {
                if (webView.canGoBack()) webView.goBack();
                else finish();
            });
        }

        @JavascriptInterface
        public void showToast(String message) {
            runOnUiThread(() ->
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show()
            );
        }

        @JavascriptInterface
        public String savePdf(String base64Data, String fileName) {
            try {
                // Create HBD Invoices directory
                File dir;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "HBD Invoices");
                } else {
                    dir = new File(Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_DOWNLOADS), "HBD Invoices");
                }
                if (!dir.exists()) dir.mkdirs();

                // Clean filename
                String cleanName = fileName.replaceAll("[^a-zA-Z0-9._\\-]", "_");
                if (!cleanName.endsWith(".pdf")) cleanName += ".pdf";
                File pdfFile = new File(dir, cleanName);

                // Decode base64 and write
                byte[] pdfBytes = Base64.decode(base64Data, Base64.DEFAULT);
                FileOutputStream fos = new FileOutputStream(pdfFile);
                fos.write(pdfBytes);
                fos.close();

                // Notify media scanner
                Intent scanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                scanIntent.setData(Uri.fromFile(pdfFile));
                sendBroadcast(scanIntent);

                return "saved:" + pdfFile.getAbsolutePath();
            } catch (Exception e) {
                return "error:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public void sharePdf(String filePath, String subject) {
            runOnUiThread(() -> {
                try {
                    File file = new File(filePath);
                    if (!file.exists()) {
                        Toast.makeText(MainActivity.this, "File not found", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Uri fileUri = FileProvider.getUriForFile(MainActivity.this,
                            "com.hbdprocast.billing.fileprovider", file);
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("application/pdf");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(shareIntent, "Share Invoice via"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Share failed: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareWhatsApp(String filePath, String message) {
            runOnUiThread(() -> {
                try {
                    File file = new File(filePath);
                    Uri fileUri = FileProvider.getUriForFile(MainActivity.this,
                            "com.hbdprocast.billing.fileprovider", file);
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("application/pdf");
                    intent.setPackage("com.whatsapp");
                    intent.putExtra(Intent.EXTRA_TEXT, message);
                    intent.putExtra(Intent.EXTRA_STREAM, fileUri);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(intent);
                } catch (Exception e) {
                    // WhatsApp not installed, use generic share
                    sharePdf(filePath, message);
                }
            });
        }

        @JavascriptInterface
        public void printWebView(String html) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                    if (printManager != null) {
                        WebView printWebView = new WebView(MainActivity.this);
                        printWebView.setWebViewClient(new WebViewClient() {
                            @Override
                            public void onPageFinished(WebView view, String url) {
                                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter("HBD Invoice");
                                PrintAttributes.Builder builder = new PrintAttributes.Builder();
                                builder.setMediaSize(PrintAttributes.MediaSize.ISO_A4);
                                builder.setResolution(new PrintAttributes.Resolution("pdf", "pdf", 600, 600));
                                builder.setMinMargins(PrintAttributes.Margins.NO_MARGINS);
                                printManager.print("HBD Invoice", adapter, builder.build());
                            }
                        });
                        printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                    }
                }
            });
        }

        @JavascriptInterface
        public String getStoragePath() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "HBD Invoices");
                return dir.getAbsolutePath();
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "HBD Invoices");
                return dir.getAbsolutePath();
            }
        }

        @JavascriptInterface
        public boolean isAndroid() { return true; }

        @JavascriptInterface
        public int getSdkVersion() { return Build.VERSION.SDK_INT; }
    }
}
